//
//  BorderLabel.h
//  CoolTest
//
//  Created by DTMobile on 2017/5/19.
//  Copyright © 2017年 DEV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BorderLabel : UILabel

@end
