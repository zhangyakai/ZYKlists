//
//  LeftTableView.m
//  CoolTest
//
//  Created by DTMobile on 2017/5/17.
//  Copyright © 2017年 DEV. All rights reserved.
//

#import "LeftTableView.h"

@implementation LeftTableView

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
