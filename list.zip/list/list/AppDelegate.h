//
//  AppDelegate.h
//  list
//
//  Created by DTMobile on 2017/5/19.
//  Copyright © 2017年 DTMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

